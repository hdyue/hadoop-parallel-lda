package org.thunlp.tool;

public interface GenericTool {
	public void run( String [] args) throws Exception;
}
